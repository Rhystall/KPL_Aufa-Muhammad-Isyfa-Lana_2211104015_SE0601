﻿class Program
{
    static void Main(string[] args)
    {
        var data1 = PusatDataSingleton.GetDataSingleton();
        var data2 = PusatDataSingleton.GetDataSingleton();

        data1.AddSebuahData("Aufa Muhammad");
        data1.AddSebuahData("Doanta Aloycius Ginting");
        data1.AddSebuahData("Lintang Suminar Tyas Weni");
        data1.AddSebuahData("Rezky Pratiwi");
        data1.AddSebuahData("Asisten Praktikum");

        Console.WriteLine("Print dari data2:");
        data2.PrintSemuaData();

        Console.WriteLine("\nMenghapus Asisten Praktikum...");
        data2.HapusSebuahData(data2.GetSemuaData().IndexOf("Asisten Praktikum"));

        Console.WriteLine("\nPrint dari data1 setelah penghapusan:");
        data1.PrintSemuaData();

        Console.WriteLine($"\nJumlah data di data1: {data1.GetSemuaData().Count}");
        Console.WriteLine($"Jumlah data di data2: {data2.GetSemuaData().Count}");
    }
}
