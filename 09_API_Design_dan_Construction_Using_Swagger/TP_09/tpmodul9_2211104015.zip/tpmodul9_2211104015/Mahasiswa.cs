﻿namespace tpmodul9_2211104015
{
    public class Mahasiswa
    {
        public string Nama { get; set; }
        public string Nim { get; set; }
    }

}
