﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using tpmodul12_2211104015;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestNegatif()
        {
            var form = new Form1();
            Assert.AreEqual("Negatif", form.CariTandaBilangan(-5));
        }

        [TestMethod]
        public void TestPositif()
        {
            var form = new Form1();
            Assert.AreEqual("Positif", form.CariTandaBilangan(3));
        }

        [TestMethod]
        public void TestNol()
        {
            var form = new Form1();
            Assert.AreEqual("Nol", form.CariTandaBilangan(0));
        }
    }

}
