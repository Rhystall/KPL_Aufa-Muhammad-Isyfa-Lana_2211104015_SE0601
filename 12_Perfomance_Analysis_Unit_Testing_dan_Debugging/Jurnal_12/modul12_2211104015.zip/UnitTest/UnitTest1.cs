﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using modul12_2211104015;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestB0() => Assert.AreEqual(1, Form1.CariNilaiPangkat(5, 0));
        [TestMethod]
        public void TestBNeg() => Assert.AreEqual(-1, Form1.CariNilaiPangkat(5, -2));
        [TestMethod]
        public void TestBMoreThan10() => Assert.AreEqual(-2, Form1.CariNilaiPangkat(5, 11));
        [TestMethod]
        public void TestAMoreThan100() => Assert.AreEqual(-2, Form1.CariNilaiPangkat(101, 2));
        [TestMethod]
        public void TestNormal() => Assert.AreEqual(8, Form1.CariNilaiPangkat(2, 3));
    }

}
