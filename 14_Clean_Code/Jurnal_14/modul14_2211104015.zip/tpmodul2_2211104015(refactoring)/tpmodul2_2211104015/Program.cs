﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Masukkan satu huruf: ");
        char inputChar = char.ToUpper(Console.ReadKey().KeyChar); // camelCase untuk variable
        Console.WriteLine();

        if (IsVowel(inputChar))
        {
            Console.WriteLine($"Huruf {inputChar} merupakan huruf vokal");
        }
        else
        {
            Console.WriteLine($"Huruf {inputChar} merupakan huruf konsonan");
        }

        int[] evenNumbers = { 2, 4, 6, 8, 10 };
        DisplayEvenNumbers(evenNumbers);
    }

    // PascalCase untuk method
    static bool IsVowel(char character)
    {
        return "AIUEO".Contains(character);
    }

    static void DisplayEvenNumbers(int[] numbers)
    {
        for (int i = 0; i < numbers.Length; i++)
        {
            Console.WriteLine($"Angka genap {i + 1} : {numbers[i]}");
        }
    }
}
