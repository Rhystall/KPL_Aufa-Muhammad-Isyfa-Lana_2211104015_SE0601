﻿using System;
using AljabarLibraries;

class Program
{
    static void Main(string[] args)
    {
        double[] persamaan1 = { 1, -3, -10 };
        double[] akar = Aljabar.AkarPersamaanKuadrat(persamaan1);
        Console.WriteLine("Akar-akar dari persamaan kuadrat:");
        foreach (var a in akar)
        {
            Console.WriteLine(a);
        }

        double[] persamaan2 = { 2, -3 };
        double[] hasilKuadrat = Aljabar.HasilKuadrat(persamaan2);
        Console.WriteLine("\nHasil kuadrat dari persamaan:");
        foreach (var h in hasilKuadrat)
        {
            Console.WriteLine(h);
        }
    }
}
