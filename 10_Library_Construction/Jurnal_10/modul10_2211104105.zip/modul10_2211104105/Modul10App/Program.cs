﻿using System;
using MatematikaLibraries; // Import library yang kita buat

namespace Modul10App
{
    class Program
    {
        static void Main(string[] args)
        {
            Matematika mat = new Matematika();

            Console.WriteLine("==== Testing FPB ====");
            Console.WriteLine($"FPB(60, 45) = {mat.FPB(60, 45)}");

            Console.WriteLine("\n==== Testing KPK ====");
            Console.WriteLine($"KPK(12, 8) = {mat.KPK(12, 8)}");

            Console.WriteLine("\n==== Testing Turunan ====");
            int[] polinom1 = { 1, 4, -12, 9 }; // x^3 + 4x^2 -12x + 9
            Console.WriteLine($"Turunan(x^3 + 4x^2 -12x +9) = {mat.Turunan(polinom1)}");

            Console.WriteLine("\n==== Testing Integral ====");
            int[] polinom2 = { 4, 6, -12, 9 }; // 4x^3 + 6x^2 -12x +9
            Console.WriteLine($"Integral(4x^3 + 6x^2 -12x +9) = {mat.Integral(polinom2)}");

            Console.WriteLine("\nSelesai! Tekan Enter untuk keluar...");
            Console.ReadLine();
        }
    }
}
