﻿using System;

namespace MatematikaLibraries
{
    public class Matematika
    {
        // FPB
        public int FPB(int input1, int input2)
        {
            while (input2 != 0)
            {
                int temp = input2;
                input2 = input1 % input2;
                input1 = temp;
            }
            return input1;
        }

        // KPK
        public int KPK(int input1, int input2)
        {
            return (input1 * input2) / FPB(input1, input2);
        }

        // Turunan
        public string Turunan(int[] persamaan)
        {
            string hasil = "";
            int pangkat = persamaan.Length - 1;

            for (int i = 0; i < persamaan.Length - 1; i++)
            {
                int koefisienBaru = persamaan[i] * pangkat;
                if (koefisienBaru == 0)
                {
                    pangkat--;
                    continue;
                }
                if (hasil != "" && koefisienBaru > 0)
                    hasil += " + ";
                else if (koefisienBaru < 0)
                    hasil += " ";

                hasil += $"{koefisienBaru}";
                if (pangkat - 1 > 0)
                    hasil += $"x{pangkat - 1}";
                pangkat--;
            }
            return hasil.Trim();
        }

        // Integral
        public string Integral(int[] persamaan)
        {
            string hasil = "";
            int pangkat = persamaan.Length;

            for (int i = 0; i < persamaan.Length; i++)
            {
                double koefisienBaru = (double)persamaan[i] / pangkat;

                if (hasil != "" && koefisienBaru > 0)
                    hasil += " + ";
                else if (koefisienBaru < 0)
                    hasil += " ";

                if (koefisienBaru == 1)
                    hasil += $"x{pangkat}";
                else if (koefisienBaru == -1)
                    hasil += $"-x{pangkat}";
                else
                    hasil += $"{koefisienBaru}x{pangkat}";

                pangkat--;
            }
            hasil += " + C";
            return hasil.Trim();
        }
    }
}
