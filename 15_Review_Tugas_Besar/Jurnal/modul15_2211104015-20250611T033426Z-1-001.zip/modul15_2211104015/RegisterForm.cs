﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace modul15_2211104015
{
    public partial class RegisterForm : Form
    {
        public RegisterForm()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtUsernameReg.Text.Trim();
            string password = txtPasswordReg.Text;

            // Validasi panjang username
            if (username.Length < 4 || username.Length > 20)
            {
                MessageBox.Show("Username harus 4-20 karakter.");
                return;
            }

            // Validasi panjang password
            if (password.Length < 8 || password.Length > 20)
            {
                MessageBox.Show("Password harus 8-20 karakter.");
                return;
            }

            // Validasi angka dan simbol
            if (!password.Any(char.IsDigit) || !password.Any(c => char.IsSymbol(c) || char.IsPunctuation(c)))
            {
                MessageBox.Show("Password harus mengandung minimal 1 angka dan 1 simbol.");
                return;
            }

            // Password tidak boleh mengandung username
            if (password.ToLower().Contains(username.ToLower()))
            {
                MessageBox.Show("Password tidak boleh mengandung username.");
                return;
            }

            // Cek duplikasi username
            if (UserService.FindUser(username) != null)
            {
                MessageBox.Show("Username sudah digunakan.");
                return;
            }

            // Simpan user
            string hashedPassword = SecurityHelper.HashPassword(password);
            User newUser = new User { Username = username, PasswordHash = hashedPassword };
            UserService.AddUser(newUser);

            MessageBox.Show("Registrasi berhasil!");
            this.Close(); // Tutup form registrasi
        }

        private void btnToLogin_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
        }

    }

    // Class user
    public class User
    {
        public string Username { get; set; }
        public string PasswordHash { get; set; }
    }

    // Service simpan/load JSON
    public static class UserService
    {
        private static string filePath = "users.json";

        public static List<User> LoadUsers()
        {
            if (!File.Exists(filePath))
                return new List<User>();

            string json = File.ReadAllText(filePath);
            return JsonConvert.DeserializeObject<List<User>>(json);
        }

        public static void SaveUsers(List<User> users)
        {
            string json = JsonConvert.SerializeObject(users, Formatting.Indented);
            File.WriteAllText(filePath, json);
        }

        public static void AddUser(User user)
        {
            var users = LoadUsers();
            users.Add(user);
            SaveUsers(users);
        }

        public static User FindUser(string username)
        {
            return LoadUsers().Find(u => u.Username == username);
        }
    }

    // Hash password
    public static class SecurityHelper
    {
        public static string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] input = Encoding.UTF8.GetBytes(password);
                byte[] hash = sha256.ComputeHash(input);
                return Convert.ToBase64String(hash);
            }
        }
    }
}
